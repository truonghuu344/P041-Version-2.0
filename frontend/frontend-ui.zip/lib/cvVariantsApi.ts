export type VariantMode = 'HAS_CV' | 'NO_CV';
export type VariantStatus = 'DRAFT' | 'DRAFT_BLOCKED' | 'VALIDATED' | 'PUBLISHED';

export interface CVSummary {
  id: string;
  title: string;
}

export interface JDSummary {
  id: string;
  title: string;
  company?: string | null;
}

export interface VariantSuggestion {
  id: string;
  block_id?: string;
  section?: string;
  original: string;
  proposed: string;
  final_text?: string;
  reason?: string;
  jd_alignment?: string[];
  source_evidence_ids?: string[];
  source_spans?: Array<{ text: string; start?: number; end?: number }>;
  decision: 'pending' | 'accept' | 'reject' | 'edit' | 'unavailable';
  is_actionable?: boolean;
  validator_status: string;
}

export interface VariantGapAnalysis {
  missing_skills: string[];
  missing_sections: string[];
  blueprint: {
    title: string;
    skills: string[];
    description: string;
    deliverables: string[];
    draft_bullet: string;
  } | null;
  insufficient_evidence?: boolean;
}

export interface VariantContent {
  personal_info: Record<string, string>;
  headline?: string;
  summary: string;
  skills: string[];
  experience: Array<Record<string, unknown>>;
  projects: Array<Record<string, unknown>>;
  education: Array<Record<string, unknown>>;
  certifications?: Array<Record<string, unknown>>;
  template_name?: 'classic' | 'modern' | 'elegant' | 'compact' | 'creative';
  _suggestions?: VariantSuggestion[];
  _confirmed_claims?: string[];
  _match_scores?: { before: number; after_preview: number };
  _gap_analysis?: VariantGapAnalysis;
  _source_confirmed?: boolean;
}

export interface VariantValidation {
  variant_id: string;
  status: VariantStatus;
  passed: boolean;
  content_hash: string;
  validators: Array<{ name: string; passed: boolean; errors: string[] }>;
  claims_total: number;
  claims_supported: number;
  claims_blocked: number;
  ats_score?: number;
  ats_content_coverage?: number;
  jd_keyword_coverage?: number;
  verification_status?: 'Verified source = 100%' | 'Partially verified' | 'Insufficient evidence';
  render: { pages: number; bytes: number; template: string };
  trace_id: string;
}

export interface CVVariant {
  id: string;
  title: string;
  mode: VariantMode;
  status: VariantStatus;
  content: VariantContent;
  template: { id: string; name: 'classic' | 'modern' | 'elegant' | 'compact' | 'creative'; version: number };
  ai_metadata: {
    provider?: string;
    model?: string;
    fallback_used?: boolean;
    prompt_version?: string;
    latency_ms?: number;
  };
  validator_result: VariantValidation | null;
  rendered_checksum: string | null;
  revision_no: number;
  trace_id: string;
  created_at?: string;
  updated_at?: string;
  revisions: Array<{
    revision_no: number;
    editor_type: string;
    change_summary?: string;
    created_at: string;
  }>;
}

function safeApiError(status: number): string {
  if (status === 401) return 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
  if (status === 403) return 'Bạn không có quyền thực hiện thao tác này.';
  if (status === 404) return 'Dữ liệu không còn tồn tại hoặc không khả dụng.';
  if (status === 409) return 'Thao tác này chưa thể thực hiện ở trạng thái hiện tại.';
  if (status === 422) return 'Dữ liệu chưa hợp lệ. Vui lòng kiểm tra lại thông tin.';
  if (status === 429) return 'Hệ thống đang bận. Vui lòng thử lại sau ít phút.';
  return 'Đã xảy ra sự cố. Vui lòng thử lại sau.';
}

async function responseError(response: Response, parsedBody?: { detail?: unknown; message?: unknown } | null): Promise<string> {
  const fallback = safeApiError(response.status);
  const body = parsedBody ?? (await response.json().catch(() => null)) as { detail?: unknown; message?: unknown } | null;
  const detail = body?.detail ?? body?.message;
  if (typeof detail === 'string' && detail.trim()) return detail;
  return fallback;
}

const API_ORIGIN = process.env.NEXT_PUBLIC_API_BASE_URL || '';

const API_BASE_URL = API_ORIGIN
  ? `${API_ORIGIN}/api/v1`
  : '/api/v1';

const API_V2_BASE_URL = API_ORIGIN
  ? `${API_ORIGIN}/api/v2`
  : '/api/v2';

function resolveApiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  if (path.startsWith('/api/v2')) {
    return `${API_V2_BASE_URL}${path.slice('/api/v2'.length)}`;
  }
  if (path.startsWith('/api/v1')) {
    return `${API_BASE_URL}${path.slice('/api/v1'.length)}`;
  }
  return `${API_BASE_URL}${path}`;
}

function authHeaders(extra: Record<string, string> = {}): Record<string, string> {
  const token = typeof window === 'undefined' ? null : window.localStorage.getItem('access_token');
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

async function requestJson<T>(url: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(resolveApiUrl(url), {
    ...init,
    credentials: 'include',
    headers: authHeaders({
      'Content-Type': 'application/json',
      ...((init.headers as Record<string, string>) || {}),
    }),
  });
  const body = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(await responseError(response, body));
  }
  return body as T;
}

export const cvVariantsApi = {
  async prerequisites(): Promise<{ cvs: CVSummary[]; jds: JDSummary[] }> {
    const [cvs, jds] = await Promise.all([
      requestJson<CVSummary[]>('/api/v1/cvs'),
      requestJson<JDSummary[]>('/api/v1/jds'),
    ]);
    return { cvs: Array.isArray(cvs) ? cvs : [], jds: Array.isArray(jds) ? jds : [] };
  },

  create(payload: Record<string, unknown>, idempotencyKey: string): Promise<CVVariant> {
    return requestJson('/api/v2/cv-variants', {
      method: 'POST',
      headers: { 'Idempotency-Key': idempotencyKey },
      body: JSON.stringify(payload),
    });
  },

  list(): Promise<{ items: CVVariant[]; total: number }> {
    return requestJson('/api/v2/cv-variants');
  },

  get(id: string): Promise<CVVariant> {
    return requestJson(`/api/v2/cv-variants/${encodeURIComponent(id)}`);
  },

  autosave(
    id: string,
    content: VariantContent,
    confirmedClaims: string[] = [],
  ): Promise<CVVariant> {
    return requestJson(`/api/v2/cv-variants/${encodeURIComponent(id)}`, {
      method: 'PATCH',
      body: JSON.stringify({
        content,
        confirmed_claims: confirmedClaims,
        change_summary: 'Autosave từ CV wizard',
      }),
    });
  },

  decide(
    id: string,
    suggestionId: string,
    decision: 'accept' | 'reject' | 'edit',
    finalText?: string,
  ): Promise<CVVariant> {
    return requestJson(
      `/api/v2/cv-variants/${encodeURIComponent(id)}/suggestions/${encodeURIComponent(suggestionId)}`,
      {
        method: 'PUT',
        body: JSON.stringify({ decision, final_text: finalText || null }),
      },
    );
  },

  validate(id: string): Promise<VariantValidation> {
    return requestJson(`/api/v2/cv-variants/${encodeURIComponent(id)}/validate`, {
      method: 'POST',
    });
  },

  publish(id: string): Promise<{ checksum: string; download_url: string; status: 'PUBLISHED' }> {
    return requestJson(`/api/v2/cv-variants/${encodeURIComponent(id)}/publish`, { method: 'POST' });
  },

  async createCustomJd(payload: {
    title: string;
    company?: string;
    requirements_text: string;
  }): Promise<JDSummary> {
    const result = await requestJson<{ id: string; title: string; company?: string | null }>(
      '/api/v1/jds/custom',
      {
        method: 'POST',
        body: JSON.stringify({
          title: payload.title,
          company: payload.company || '',
          location: '',
          requirements_text: payload.requirements_text,
        }),
      },
    );
    return {
      id: result.id,
      title: result.title,
      company: result.company,
    };
  },

  async pdf(id: string, preview = false): Promise<Blob> {
    const response = await fetch(
      resolveApiUrl(`/api/v2/cv-variants/${encodeURIComponent(id)}/export${preview ? '?preview=true' : ''}`),
      {
        credentials: 'include',
        headers: authHeaders(),
      },
    );
    if (!response.ok) {
      throw new Error(await responseError(response));
    }
    return response.blob();
  },
};
